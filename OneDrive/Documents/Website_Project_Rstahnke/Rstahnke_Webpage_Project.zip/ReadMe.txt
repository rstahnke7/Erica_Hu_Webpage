ReadMe
Please find enclosed in this zip drive the following files:
* Index_WebsiteP.html (this is the index for the website)
The following  four files are for the navigation bar elements:
* Events_WP.html
* Menu_WP.html
* Location_WP.html
* Contact_WP.html
All of the CSS styling is found in �styles_WP.css�.
This is a simple website that Erica Hu could potentially use as a personal website to promote her teaching and performances. 


